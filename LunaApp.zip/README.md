# Luna — Ready-to-Build Kivy Android App

This repository contains a ready-to-build Kivy app for Luna (a warm female voice assistant).

How to build (simple):
1. Create a new GitHub repository and upload these files.
2. Commit to the `main` branch. The included GitHub Actions workflow will run Buildozer on Ubuntu and produce an APK artifact.
3. When the Actions run completes, open the run and download the `luna-apk` artifact (the APK).

Notes:
- The APK is a debug build. Allow installation from unknown sources on your phone.
- On Android the app will request microphone permission. Grant it when prompted.
- For better AI replies, set `OPENAI_API_KEY` as a repository secret or device environment variable.
- If the Actions build fails, paste the workflow run link here and I will help fix it.
