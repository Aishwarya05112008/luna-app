#!/usr/bin/env python3
# Luna mobile chat UI - simplified and stable for Buildozer

import os, json, re, random, time, datetime as dt, webbrowser
from pathlib import Path

# Optional OpenAI support (set OPENAI_API_KEY in GitHub secrets or device env)
try:
    import openai
    OPENAI = True
    openai.api_key = os.getenv("OPENAI_API_KEY") or ""
    if not openai.api_key:
        OPENAI = False
except Exception:
    OPENAI = False

import requests
import speech_recognition as sr
from googletrans import Translator

from kivy.app import App
from kivy.lang import Builder
from kivy.clock import mainthread
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty

# Plyer TTS on Android, fallback to pyttsx3 on desktop
try:
    from plyer import tts as plyer_tts
    PLYER_TTS = True
except Exception:
    PLYER_TTS = False

try:
    import pyttsx3
    py_engine = pyttsx3.init()
    py_engine.setProperty("rate", 165)
except Exception:
    py_engine = None

APP_DIR = Path.home() / ".luna_app"
APP_DIR.mkdir(exist_ok=True)
MEMORY_FILE = APP_DIR / "luna_memory.json"
REMINDERS_FILE = APP_DIR / "luna_reminders.json"

ASSISTANT_NAME = "Luna"
DEFAULT_USER = "Aishwarya"

# Load memory
def load_json(path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default
    return default

def save_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

memory = load_json(MEMORY_FILE, {"user_name": DEFAULT_USER, "language": "en", "facts": {}, "flashcards": [], "chat_history": []})
reminders = load_json(REMINDERS_FILE, [])

recognizer = sr.Recognizer() if sr else None
translator = Translator() if Translator else None

KV = """
<LunaRoot>:
    orientation: "vertical"
    padding: 10
    spacing: 8

    BoxLayout:
        size_hint_y: None
        height: "48dp"
        Label:
            text: app.title_text
            bold: True
        Button:
            text: "Speak"
            size_hint_x: None
            width: "110dp"
            on_release: root.start_listen()

    ScrollView:
        do_scroll_x: False
        Label:
            id: chat
            text: root.chat_log
            size_hint_y: None
            height: self.texture_size[1]
            text_size: self.width, None

    BoxLayout:
        size_hint_y: None
        height: "48dp"
        TextInput:
            id: text_in
            hint_text: "Type a message..."
        Button:
            text: "Send"
            size_hint_x: None
            width: "90dp"
            on_release: root.on_send(text_in.text)
"""

class LunaRoot(BoxLayout):
    chat_log = StringProperty("")

    def append(self, text):
        self.chat_log += text + "\\n"

    def start_listen(self):
        self.append("...listening...")
        from threading import Thread
        Thread(target=self._listen_thread, daemon=True).start()

    def _listen_thread(self):
        txt = recognize_from_mic()
        if txt:
            self.process_user(txt)

    @mainthread
    def on_send(self, text):
        if not text.strip():
            return
        self.process_user(text)

    def process_user(self, text):
        self.append("You: " + text)
        lower = text.lower()

        if "what can you do" in lower or "what do you do" in lower:
            out = describe_capabilities()
            self.append(ASSISTANT_NAME + ": " + out)
            speak(out, memory.get("language","en"))
            return

        if "play " in lower:
            song = re.sub(r"play\\s+", "", lower, count=1)
            song = song.replace("song","").replace("music","").strip()
            if not song:
                speak("Which song would you like me to play?", memory.get("language","en"))
                return
            open_youtube_music(song)
            out = f"Opening YouTube Music for {song}"
            self.append(ASSISTANT_NAME + ": " + out)
            speak(out, memory.get("language","en"))
            return

        if "time" in lower and "what" in lower:
            out = dt.datetime.now().strftime("%I:%M %p")
            self.append(ASSISTANT_NAME + ": " + out)
            speak("The time is " + out, memory.get("language","en"))
            return

        if "date" in lower and "what" in lower:
            out = dt.datetime.now().strftime("%A, %d %B %Y")
            self.append(ASSISTANT_NAME + ": " + out)
            speak("Today is " + out, memory.get("language","en"))
            return

        if "weather" in lower:
            m = re.search(r"in\\s+([a-zA-Z\\s]+)", lower)
            city = m.group(1).strip() if m else "your location"
            out = get_weather(city)
            self.append(ASSISTANT_NAME + ": " + out)
            speak(out, memory.get("language","en"))
            return

        if OPENAI:
            ans = ai_answer(text)
        else:
            ans = web_search_ddg(text)
        self.append(ASSISTANT_NAME + ": " + ans)
        speak(ans, memory.get("language","en"))

# Helpers
def recognize_from_mic(timeout=6, phrase_time_limit=10):
    if not recognizer:
        return ""
    try:
        with sr.Microphone() as source:
            recognizer.adjust_for_ambient_noise(source, duration=0.6)
            audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
        return recognizer.recognize_google(audio)
    except Exception:
        return ""

def speak(text, lang="en"):
    out = text
    try:
        if translator and lang and lang != "en":
            out = translator.translate(text, dest=lang).text
    except Exception:
        out = text
    try:
        if PLYER_TTS:
            plyer_tts.speak(out)
            return
    except Exception:
        pass
    try:
        if py_engine:
            py_engine.say(out)
            py_engine.runAndWait()
            return
    except Exception:
        pass
    print(ASSISTANT_NAME + ": " + out)

def web_search_ddg(query):
    try:
        url = "https://api.duckduckgo.com/"
        params = {"q": query, "format": "json", "no_html": 1, "skip_disambig": 1}
        r = requests.get(url, params=params, timeout=6)
        j = r.json()
        if j.get("AbstractText"):
            return j["AbstractText"]
        topics = j.get("RelatedTopics", [])
        if topics:
            for t in topics:
                if isinstance(t, dict) and t.get("Text"):
                    return t["Text"]
        return "I couldn't find a short answer — shall I open the web?"
    except Exception:
        return "Web search error."

def open_youtube_music(query):
    q = query.strip().replace(" ", "+")
    webbrowser.open(f"https://music.youtube.com/search?q={q}", new=2)

def get_weather(city):
    try:
        url = f"http://wttr.in/{city.replace(' ','+')}?format=j1"
        r = requests.get(url, timeout=6)
        j = r.json()
        curr = j.get("current_condition",[{}])[0]
        desc = curr.get("weatherDesc",[{}])[0].get("value","")
        temp = curr.get("temp_C","")
        return f"{city.title()}: {desc}. {temp}°C."
    except Exception:
        return "Weather fetch failed."

def ai_answer(prompt):
    if not OPENAI:
        return web_search_ddg(prompt)
    try:
        resp = openai.ChatCompletion.create(model="gpt-3.5-turbo",
                                           messages=[{"role":"system","content":"You are Luna, a warm assistant."},
                                                     {"role":"user","content":prompt}], temperature=0.5, max_tokens=300)
        return resp.choices[0].message.content.strip()
    except Exception:
        return web_search_ddg(prompt)

def describe_capabilities():
    return ("I can chat, remember things, translate languages, search the web, tell weather, set reminders, "
            "play music on YouTube Music, tell jokes and help you study.")

# Kivy app wiring
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty

class LunaAppRoot(BoxLayout):
    pass

from kivy.app import App
class LunaApp(App):
    title = "Luna — Your warm assistant"
    title_text = StringProperty("Luna — warm assistant")
    def build(self):
        return Builder.load_string(KV)

if __name__ == "__main__":
    LunaApp().run()
